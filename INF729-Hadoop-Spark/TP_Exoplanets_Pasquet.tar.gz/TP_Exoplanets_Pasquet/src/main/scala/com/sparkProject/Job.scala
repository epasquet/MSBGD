package com.sparkProject

import org.apache.spark.sql.SparkSession

object Job {

  def main(args: Array[String]): Unit = {

    // SparkSession configuration
    val spark = SparkSession
      .builder
      .appName("spark session TP_parisTech")
      .getOrCreate()

    val sc = spark.sparkContext

    import spark.implicits._


    /********************************************************************************
      *
      *        TP 1
      *
      *        - Set environment, IntelliJ, submit jobs to Spark
      *        - Load local unstructured data
      *        - Word count , Map Reduce
      ********************************************************************************/



    /* ----------------- word count ------------------------

     val df_wordCount = sc.textFile("/home/nux/spark-2.0.0-bin-hadoop2.6/README.md")
      .flatMap{case (line: String) => line.split(" ")}
      .map{case (word: String) => (word, 1)}
      .reduceByKey{case (i: Int, j: Int) => i + j}
      .toDF("word", "count")

    /df_wordCount.orderBy($"count".desc).show()
    */

    /********************************************************************************
      *
      *        TP 2 : début du projet
      *
      ********************************************************************************/

    // ----------------- load planets ----------------------

    val df = spark
      .read // returns a DataFrameReader, giving access to methods “options” and “csv”
      .option("header", "true") // Use first line of all files as header
      .option("inferSchema", "true") // Automatically infer data types
      .option("comment", "#") // All lines starting with # are ignored
      .csv("/home/nux/IdeaProjects/20161010_TP_2-3/tp_spark/cumulative.csv")

    // println("number of columns", df.columns.length) //df.columns returns an Array of columns names, and arrays have a method “length” returning their length
    // println("number of rows", df.count)

    import org.apache.spark.sql.functions._
    // val columns = df.columns.slice(1, 11) // df.columns returns an Array. In scala arrays have a method “slice” returning a slice of the array
    // df.select(columns.map(col): _*).show(50) //

    // df.printSchema()

    // df.groupBy("koi_disposition").count().show()

    // val cdf = df.where("koi_disposition = 'CONFIRMED' or koi_disposition = 'FALSE POSITIVE'")
    // val c_columns = cdf.columns.slice(20, 30)
    // cdf.select(c_columns.map(col): _*).show(10)
    // cdf.groupBy("koi_disposition").count().show()

    // cdf.groupBy("koi_eccen_err1").count().show() //count().orderBy($"count".desc).
    // cdf.select("koi_eccen_err1").distinct().show()
    // cdf.select($"koi_eccen_err1").distinct().show()

    // Remove column koi_eccen_err1
    val df_light = df
                    .where("koi_disposition = 'CONFIRMED' or koi_disposition = 'FALSE POSITIVE'")
                    .drop("koi_eccen_err1", "index", "kepid", "koi_fpflag_nt",
                      "koi_fpflag_ss", "koi_fpflag_co",
                      "koi_sparprov", "koi_trans_mod", "koi_datalink_dvr",
                      "koi_datalink_dvs", "koi_tce_delivname", "koi_parm_prov",
                      "koi_limbdark_mod", "koi_fittype", "koi_disp_prov",
                      "koi_comment", "kepoi_name", "kepler_name", "koi_vet_date",
                      "koi_fpflag_ec", "koi_pdisposition")

    // df_light.printSchema()
    // val d_columns = cdf_light.columns.slice(20, 30)
    // cdf.select(d_columns.map(col): _*).show(10)

    //////////////            CLEANING              ///////////////////

    // Dropper les colonnes vides ou ayant une seule valeur

    /*
    // Créer un df pour lister les colonnes qu'on garde
    df_cols = []
    // Boucle sur les colonnes
    while (colonnes)
    // Boucle sur les lignes
        // dès que le count de valeurs distincts dépasse 1, on "continue"
        if (df.groupBy("koi_vet_date").count() <= 1) {
            df_cols.
        }
    */

    val useless_column = df_light
                      .columns
                      .filter{ case (column:String) =>
                          df_light.agg(countDistinct(column)).first().getLong(0) <= 1 }

    val df_light_2 = df_light.drop(useless_column: _*)

    //df_light_2.describe("koi_impact", "koi_duration").show()

    val df_light_filled = df_light_2.na.fill(0.0)


    //////////////        AJOUT COLONNES ROR Min et Max             ///////////////////

    def udf_sum = udf((col1: Double, col2: Double) => col1 + col2)

    val df_newFeatures = df_light_filled
      .withColumn("koi_ror_min", udf_sum($"koi_ror", $"koi_ror_err2"))
      .withColumn("koi_ror_max", $"koi_ror" + $"koi_ror_err1")

    df_newFeatures
      .coalesce(1) // optional : regroup all data in ONE partition, so that results are printed in ONE file
      // >>>> You should not do that in general, only when the data are small enough to fit in the memory of a single machine.
      .write
      .mode("overwrite")
      .option("header", "true")
      .csv("/home/nux/IdeaProjects/20161010_TP_2-3/tp_spark/cleanedDataFrame.csv")

  }

}
